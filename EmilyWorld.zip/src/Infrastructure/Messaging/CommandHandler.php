<?php

namespace EmilysWorld\Infrastructure\Messaging;

/**
 * Interface CommandHandler
 * @package Infrastructure\Messaging
 * @since 1.0.0
 */
interface CommandHandler
{

}