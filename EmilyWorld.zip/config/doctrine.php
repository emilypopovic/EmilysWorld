<?php

return [
    'driver' => 'pdo_sqlite',
    'path' => __DIR__ . '/db.sqlite',
    'charset' => 'utf-8'
];
