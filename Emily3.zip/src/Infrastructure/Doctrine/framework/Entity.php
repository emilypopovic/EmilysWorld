<?php

namespace EmilysWorld\Infrastructure\Doctrine\framework;


interface Entity
{
}