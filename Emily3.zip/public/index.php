<?php

use EmilysWorld\Base\EmilysApp;

include_once __DIR__ . '/../config/bootstrap.php';

$app = new EmilysApp();

include_once __DIR__ . '/../config/routes.php';


echo "---------\n";
echo "hi world\n";


$app->run();


